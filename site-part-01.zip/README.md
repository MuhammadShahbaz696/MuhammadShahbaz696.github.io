# Muhammad Shahbaz portfolio

Static website for GitHub Pages.

Upload these files at the root of a public repository named YOUR-USERNAME.github.io. Under Settings > Pages, publish from main and /(root). Keep index.html at the repository root. A custom .com domain can be connected later after registration.
